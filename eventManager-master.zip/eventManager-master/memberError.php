<?php
    include 'includes/head.php';

    /*<div class="hero-unit" id="header">
  		<center>
        	<h1>#Follow</h1>
  		    <p>Follow hash tags easy!!</p>
        </center>
    </div>*/

    echo '<center><div class="alert" style="width:450px;">
  		<strong>Warning!</strong> You must be logged in to see this page. <a href="index.php">Go to start page.</a>
  	</div></center>';
?>

</body>
</html>