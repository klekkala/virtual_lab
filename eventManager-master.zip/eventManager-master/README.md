Event Management Portal
==============

(CS251 Assignment 4) 
