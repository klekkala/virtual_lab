<div class="alert alert-success">
	
<center>You are in! Click <a href='member.php' </a>here to enter member page</center>

</div>